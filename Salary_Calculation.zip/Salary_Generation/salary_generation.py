#!/usr/bin/python

# Python method to calculate salary using excel spreadsheets
# A Paid tool method : https://www.youtube.com/watch?time_continue=6&v=9Xn-K6kIKm0

import pandas as pd

def salary_sheet(*args):
    #creating list comprehension of args
    books = [wb for wb in args]
    #creating respective dataframes for args passed
    df_1 = pd.read_excel(books[0])
    df_2 = pd.read_excel(books[1])
    df_3 = pd.read_excel(books[2])
    ''' calling merge method to create master output dataframe Note pd.merge accepts only 2 args hence we are
    calling in below way '''
    df = pd.merge(pd.merge(df_1, df_2), df_3)

    #Adding Net_Basic_Salary column with below formula similar to excel
    df['Net_Basic_Salary'] = (df['Basic_Salary'] - df['Basic_Salary'] / df['Present_Days']) * df['Leave']
    #converting Net_Basic_Salary column to integer type
    df['Net_Basic_Salary'] = df.Net_Basic_Salary.astype(int)

    #Adding NetAllowances column
    df['NetAllowances'] = (df['Allowances'] - df['Allowances'] / df['Present_Days']) * df['Leave']
    #converting below column with datatype integer
    df['NetAllowances'] = df.NetAllowances.astype(int)

    # Adding Federal_Tax column
    df['Federal_Tax'] = df['Net_Basic_Salary'] * 0.25
    #converting below column with datatype integer
    df['Federal_Tax'] = df.Federal_Tax.astype(int)

    # Adding State_Tax column
    df['State_Tax'] = df['Net_Basic_Salary'] * 0.03
    #converting below column with datatype integer
    df['State_Tax'] = df.State_Tax.astype(int)

    #Adding Total_Salary column
    df['Total_Salary'] = (df['Net_Basic_Salary'] + df['NetAllowances']) - (df['Federal_Tax'] + df['State_Tax'])
    print df.head()
    df.to_excel('Salary_Generated.xlsx',index=False)


#calling the required fucntion
salary_sheet("File1.xlsx","File2.xlsx","File3.xlsx")